package com.lite.machinelite.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_20;
import net.minecraft.class_22;

@Mixin(class_22.class)
public interface IMixinMapData {
    @Accessor("decorations")
    Map<String, class_20> getMapDecorations();
}

