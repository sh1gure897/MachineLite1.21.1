package com.lite.machinelite.mixin.client;

import com.lite.machinelite.event.impl.RenderOverlayEvent;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class MixinGuiIngame {
    @Inject(method = "renderMainHud", at = @At("RETURN"))
    private void renderMainHud(class_332 context, class_9779 tickCounter, CallbackInfo callbackInfo) {
        RenderOverlayEvent renderOverlayEvent = new RenderOverlayEvent();
        renderOverlayEvent.fire(context, tickCounter.method_60637(true)).call();
    }
}

