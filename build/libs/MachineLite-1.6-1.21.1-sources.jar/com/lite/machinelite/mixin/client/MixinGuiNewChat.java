package com.lite.machinelite.mixin.client;

import com.google.common.collect.Lists;
import com.lite.machinelite.event.impl.ChatInputEvent;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_338;
import net.minecraft.class_7469;
import net.minecraft.class_7591;

@Mixin(class_338.class)
public class MixinGuiNewChat {
    @Final
    @Shadow
    private final List<class_303.class_7590> visibleMessages = Lists.newArrayList();

    private static boolean preventRecursion = false;

    @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V", at = @At("HEAD"), cancellable = true)
    public void addMessage(class_2561 message, class_7469 signature, class_7591 indicator, CallbackInfo ci) {
        if (preventRecursion)
            return;

        ChatInputEvent chatInputEvent = new ChatInputEvent(message, visibleMessages);
        chatInputEvent.call();

        if (chatInputEvent.isCancelled()) {
            ci.cancel();
            if (chatInputEvent.isModified()) {
                preventRecursion = true;
                net.minecraft.class_310.method_1551().field_1705.method_1743()
                        .method_1812(chatInputEvent.getTextComponent());
                preventRecursion = false;
            }
        }
    }
}
