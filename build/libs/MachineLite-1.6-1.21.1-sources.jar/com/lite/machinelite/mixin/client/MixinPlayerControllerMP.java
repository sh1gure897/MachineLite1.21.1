package com.lite.machinelite.mixin.client;

import com.lite.machinelite.event.impl.EventBreakBlock;
import com.lite.machinelite.utilities.IMC;
import net.minecraft.class_2338;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class MixinPlayerControllerMP {
    @Inject(method = "breakBlock", at = @At("RETURN"))
    public void onPlayerDestroyBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        EventBreakBlock eventBreakBlock = new EventBreakBlock();
        eventBreakBlock.fire(pos, IMC.mc.field_1687.method_8320(pos)).call();
    }
}