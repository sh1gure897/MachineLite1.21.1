package com.lite.machinelite.mixin.client;

import com.lite.machinelite.event.impl.PacketEvent;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public class MixinNetworkManager {
    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void SendPacket(class_2596<?> packet, CallbackInfo callbackInfo) {
        PacketEvent packetEvent = new PacketEvent();
        packetEvent.preFire(packet).call();

        if (packetEvent.isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method = "channelRead0", at = @At("HEAD"), cancellable = true)
    private void ChannelRead(ChannelHandlerContext context, class_2596<?> packet, CallbackInfo callbackInfo) {
        PacketEvent packetEvent = new PacketEvent();
        packetEvent.postFire(packet).call();

        if (packetEvent.isCancelled()) {
            callbackInfo.cancel();
        }
    }
}

