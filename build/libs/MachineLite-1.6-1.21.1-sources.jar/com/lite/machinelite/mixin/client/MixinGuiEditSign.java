package com.lite.machinelite.mixin.client;

import com.lite.machinelite.MachineLite;
import com.lite.machinelite.module.impl.AutoSign;
import com.lite.machinelite.utilities.IMC;
import net.minecraft.class_2561;
import net.minecraft.class_2625;
import net.minecraft.class_7743;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_7743.class)
public class MixinGuiEditSign {
    @Shadow
    @Final
    private class_2625 blockEntity;

    @Shadow
    @Final
    private boolean front;

    @Shadow
    private String[] messages;

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    public void init(CallbackInfo ci) {
        if (MachineLite.getModuleManager().getModuleByString("AutoSign") != null
                && MachineLite.getModuleManager().getModuleByString("AutoSign").isEnabled()) {
            class_2561[] signText = ((AutoSign) MachineLite.getModuleManager().getModuleByString("AutoSign")).getSignText();
            if (signText != null && signText.length >= 4) {
                this.messages[0] = signText[0].getString();
                this.messages[1] = signText[1].getString();
                this.messages[2] = signText[2].getString();
                this.messages[3] = signText[3].getString();

                // In 1.21.1, sending the update packet manually is safer when closing early
                net.minecraft.class_2877 packet = new net.minecraft.class_2877(
                        this.blockEntity.method_11016(), this.front,
                        this.messages[0], this.messages[1], this.messages[2], this.messages[3]);
                IMC.mc.method_1562().method_52787(packet);

                IMC.mc.method_1507(null);
                ci.cancel();
            }
        }
    }

    @Inject(method = "finishEditing", at = @At("HEAD"))
    protected void finishEditing(CallbackInfo ci) {
        if (MachineLite.getModuleManager().getModuleByString("AutoSign") != null
                && MachineLite.getModuleManager().getModuleByString("AutoSign").isEnabled()) {
            class_2561[] newTexts = new class_2561[] {
                    class_2561.method_43470(this.messages[0] == null ? "" : this.messages[0]),
                    class_2561.method_43470(this.messages[1] == null ? "" : this.messages[1]),
                    class_2561.method_43470(this.messages[2] == null ? "" : this.messages[2]),
                    class_2561.method_43470(this.messages[3] == null ? "" : this.messages[3])
            };
            ((AutoSign) MachineLite.getModuleManager().getModuleByString("AutoSign")).setSignTexts(newTexts);
            MachineLite.WriteChat("Set SignText");
        }
    }
}
