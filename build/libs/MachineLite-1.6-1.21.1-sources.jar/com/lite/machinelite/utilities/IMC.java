package com.lite.machinelite.utilities;

import net.minecraft.class_310;

public interface IMC {
    class_310 mc = class_310.method_1551();
}
