package com.lite.machinelite.utilities;

import com.lite.machinelite.MachineLite;
import com.lite.machinelite.module.impl.AntiGhostBlock;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.network.packet.c2s.play.*;

public class Utils implements IMC {
    public static void switchItem(int slot) {
        if (mc.field_1724.method_31548().field_7545 != slot) {
            mc.field_1724.method_31548().field_7545 = slot;
            mc.method_1562().method_52787(new class_2868(slot));
        }
    }

    public static int getItemSlotByToolBar(class_1792 itemIn) {
        for (int slot = 0; slot < 9; slot++) {
            class_1799 itemStack = mc.field_1724.method_31548().method_5438(slot);
            if (itemStack.method_7909() == itemIn) {
                return slot;
            }
        }
        return -1;
    }

    public static class_2350 getFacing() {
        return mc.field_1724.method_5735();
    }

    public static boolean placeBlock(double reach, class_2338 pos) {
        class_243 eyesPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()),
                mc.field_1724.method_23321());
        final class_243 posVec = class_243.method_24953(pos);

        for (class_2350 facing : class_2350.values()) {
            final class_2338 neighbor = pos.method_10093(facing);

            class_2680 neighborState = mc.field_1687.method_8320(neighbor);
            if (!neighborState.method_45474()) { // if we can place against it
                final class_243 dirVec = new class_243(facing.method_10148(), facing.method_10164(), facing.method_10165());
                final class_243 hitVec = posVec.method_1019(dirVec.method_1021(0.5));

                if (eyesPos.method_1025(hitVec) <= Math.pow(6.0, 2.0)) {
                    float[] rotations = Utils.getNeededRotations(hitVec);
                    class_239 traceResult = Utils.rayTraceBlocks(reach, rotations[0], rotations[1]);

                    if (traceResult.method_17783() == class_239.class_240.field_1332) {
                        class_3965 blockHitResult = (class_3965) traceResult;

                        boolean needsSneak = isBlockContainer(neighborState.method_26204());
                        if (needsSneak) {
                            mc.method_1562().method_52787(
                                    new class_2848(mc.field_1724, class_2848.class_2849.field_12979));
                        }

                        class_3965 interactResult = new class_3965(hitVec, facing.method_10153(), neighbor,
                                false);
                        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, interactResult);
                        mc.method_1562().method_52787(new class_2879(class_1268.field_5808));

                        if (needsSneak) {
                            mc.method_1562().method_52787(new class_2848(mc.field_1724,
                                    class_2848.class_2849.field_12984));
                        }

                        if (MachineLite.getModuleManager().isEnabled(AntiGhostBlock.class)) {
                            // Equivalent to CPacketPlayerTryUseItemOnBlock ghost block anti-sync in 1.12
                            mc.method_1562()
                                    .method_52787(new class_2885(class_1268.field_5808, interactResult, 0));
                        }
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public static float[] getNeededRotations(class_243 vec) {
        class_243 eyesPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()),
                mc.field_1724.method_23321());
        double diffX = vec.field_1352 - eyesPos.field_1352;
        double diffY = vec.field_1351 - eyesPos.field_1351;
        double diffZ = vec.field_1350 - eyesPos.field_1350;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = mc.field_1724.method_36454()
                + class_3532.method_15393((float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F - mc.field_1724.method_36454());
        float pitch = mc.field_1724.method_36455()
                + class_3532.method_15393((float) -Math.toDegrees(Math.atan2(diffY, diffXZ)) - mc.field_1724.method_36455());
        return new float[] { yaw, pitch };
    }

    public static class_243 getVectorForRotation(float pitch, float yaw) {
        float f = class_3532.method_15362(-yaw * 0.017453292F - (float) Math.PI);
        float f1 = class_3532.method_15374(-yaw * 0.017453292F - (float) Math.PI);
        float f2 = -class_3532.method_15362(-pitch * 0.017453292F);
        float f3 = class_3532.method_15374(-pitch * 0.017453292F);
        return new class_243(f1 * f2, f3, f * f2);
    }

    public static class_239 rayTraceBlocks(double reach, float yaw, float pitch) {
        class_243 vec3 = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()),
                mc.field_1724.method_23321());
        class_243 vec4 = Utils.getVectorForRotation(pitch, yaw);
        class_243 vec5 = vec3.method_1031(vec4.field_1352 * reach, vec4.field_1351 * reach, vec4.field_1350 * reach);
        return mc.field_1724.method_37908().method_17742(new class_3959(vec3, vec5, class_3959.class_3960.field_17559,
                class_3959.class_242.field_1348, mc.field_1724));
    }

    public static boolean isBlockContainer(class_2248 block) {
        // Broad check for containers/interactive blocks
        return block == class_2246.field_10034 || block == class_2246.field_10443 || block == class_2246.field_10380 ||
                block == class_2246.field_9980 || block == class_2246.field_10181 || block == class_2246.field_16333 ||
                block == class_2246.field_16334 || block == class_2246.field_10535 || block == class_2246.field_10105 ||
                block == class_2246.field_10414 || block == class_2246.field_16328 || block == class_2246.field_10312 ||
                block == class_2246.field_10228 || block == class_2246.field_10200 || block == class_2246.field_10333 ||
                block == class_2246.field_10485;
    }

    public static boolean isBuilderBlock(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof net.minecraft.class_1747))
            return false;

        String name = net.minecraft.class_7923.field_41178.method_10221(stack.method_7909()).method_12832();

        // Prevent using functional/gravity blocks for automated building
        if (name.contains("sign") || name.contains("egg") || name.contains("anvil") ||
                name.contains("chest") || name.contains("shulker_box") || name.contains("bed") ||
                name.contains("banner") || name.contains("door") || name.contains("button") ||
                name.contains("pressure_plate") || name.contains("sand") || name.contains("gravel") ||
                name.contains("concrete_powder") || name.contains("tnt") ||
                name.contains("sapling") || name.contains("flower") || name.contains("mushroom") ||
                name.contains("torch") || name.contains("camp_fire") || name.contains("lantern") ||
                name.contains("skull") || name.contains("head") || name.contains("carpet")) {
            return false;
        }

        class_2248 block = ((net.minecraft.class_1747) stack.method_7909()).method_7711();
        if (isBlockContainer(block))
            return false;

        return true;
    }
}
