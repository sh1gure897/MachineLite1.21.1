package com.lite.machinelite.module.impl;

import com.lite.machinelite.event.Event;
import com.lite.machinelite.event.impl.UpdateEvent;
import com.lite.machinelite.module.Module;
import com.lite.machinelite.utilities.Utils;
import java.util.ArrayList;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public class AutoHighway extends Module {
    private final ArrayList<class_2338> positions = new ArrayList<>();
    private class_1792 lastBlockItem = null;

    public AutoHighway(String name, int keyCode) {
        super(name, keyCode);
    }

    @Override
    public void onEnabled() {
        this.positions.clear();
        this.lastBlockItem = null;
    }

    @Override
    public void onEvent(Event event) {
        if (!isEnabled())
            return;

        if (event instanceof UpdateEvent) {
            if (event.isPost()) {

                class_1799 mainHand = mc.field_1724.method_6047();
                if (Utils.isBuilderBlock(mainHand)) {
                    lastBlockItem = mainHand.method_7909();
                } else if (lastBlockItem != null) {
                    if (!refillBlocks()) {
                        return; // Wait until blocks are found or just fail silently
                    }
                    // Re-check after refill attempt
                    mainHand = mc.field_1724.method_6047();
                    if (!Utils.isBuilderBlock(mainHand)) {
                        return;
                    }
                } else {
                    return; // No blocks in hand and no last block
                }

                final class_243 playerPos = mc.field_1724.method_19538();
                class_2338 originPos = class_2338.method_49637(playerPos.field_1352, playerPos.field_1351 + 0.5f, playerPos.field_1350);

                if (positions.isEmpty()) {
                    switch (Utils.getFacing()) {
                        case field_11034:
                            positions.add(originPos.method_10074());
                            positions.add(originPos.method_10074().method_10078());
                            positions.add(originPos.method_10074().method_10078().method_10095());
                            positions.add(originPos.method_10074().method_10078().method_10072());
                            positions.add(originPos.method_10074().method_10078().method_10095().method_10095());
                            positions.add(originPos.method_10074().method_10078().method_10072().method_10072());
                            positions.add(originPos.method_10074().method_10078().method_10095().method_10095().method_10095());
                            positions.add(originPos.method_10074().method_10078().method_10072().method_10072().method_10072());
                            positions.add(originPos.method_10074().method_10078().method_10095().method_10095().method_10095().method_10084());
                            positions.add(originPos.method_10074().method_10078().method_10072().method_10072().method_10072().method_10084());
                            break;
                        case field_11043:
                            positions.add(originPos.method_10074());
                            positions.add(originPos.method_10074().method_10095());
                            positions.add(originPos.method_10074().method_10095().method_10078());
                            positions.add(originPos.method_10074().method_10095().method_10067());
                            positions.add(originPos.method_10074().method_10095().method_10078().method_10078());
                            positions.add(originPos.method_10074().method_10095().method_10067().method_10067());
                            positions.add(originPos.method_10074().method_10095().method_10078().method_10078().method_10078());
                            positions.add(originPos.method_10074().method_10095().method_10067().method_10067().method_10067());
                            positions.add(originPos.method_10074().method_10095().method_10078().method_10078().method_10078().method_10084());
                            positions.add(originPos.method_10074().method_10095().method_10067().method_10067().method_10067().method_10084());
                            break;
                        case field_11035:
                            positions.add(originPos.method_10074());
                            positions.add(originPos.method_10074().method_10072());
                            positions.add(originPos.method_10074().method_10072().method_10078());
                            positions.add(originPos.method_10074().method_10072().method_10067());
                            positions.add(originPos.method_10074().method_10072().method_10078().method_10078());
                            positions.add(originPos.method_10074().method_10072().method_10067().method_10067());
                            positions.add(originPos.method_10074().method_10072().method_10078().method_10078().method_10078());
                            positions.add(originPos.method_10074().method_10072().method_10067().method_10067().method_10067());
                            positions.add(originPos.method_10074().method_10072().method_10078().method_10078().method_10078().method_10084());
                            positions.add(originPos.method_10074().method_10072().method_10067().method_10067().method_10067().method_10084());
                            break;
                        case field_11039:
                            positions.add(originPos.method_10074());
                            positions.add(originPos.method_10074().method_10067());
                            positions.add(originPos.method_10074().method_10067().method_10095());
                            positions.add(originPos.method_10074().method_10067().method_10072());
                            positions.add(originPos.method_10074().method_10067().method_10095().method_10095());
                            positions.add(originPos.method_10074().method_10067().method_10072().method_10072());
                            positions.add(originPos.method_10074().method_10067().method_10095().method_10095().method_10095());
                            positions.add(originPos.method_10074().method_10067().method_10072().method_10072().method_10072());
                            positions.add(originPos.method_10074().method_10067().method_10095().method_10095().method_10095().method_10084());
                            positions.add(originPos.method_10074().method_10067().method_10072().method_10072().method_10072().method_10084());
                            break;
                    }
                }

                if (this.positions.size() <= 64) {
                    for (class_2338 pos : this.positions) {
                        if (mc.field_1687.method_8320(pos).method_45474()) {
                            Utils.placeBlock(4, pos);
                        }
                    }

                    this.positions.clear();
                }
            }
        }
    }

    private boolean refillBlocks() {
        if (mc.field_1724 == null || mc.field_1724.method_31548() == null)
            return false;

        int hotbarSlot = mc.field_1724.method_31548().field_7545;

        // Search hotbar first
        for (int i = 0; i < 9; i++) {
            if (i == hotbarSlot)
                continue;
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() == lastBlockItem) {
                Utils.switchItem(i);
                return true;
            }
        }

        // Search main inventory
        for (int i = 9; i < 36; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() == lastBlockItem) {
                if (mc.field_1761 != null) {
                    mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, i, hotbarSlot,
                            class_1713.field_7791, mc.field_1724);
                    return true;
                }
            }
        }

        return false;
    }
}
