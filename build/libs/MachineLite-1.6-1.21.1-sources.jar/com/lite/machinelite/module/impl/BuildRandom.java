package com.lite.machinelite.module.impl;

import com.lite.machinelite.event.Event;
import com.lite.machinelite.event.impl.UpdateEvent;
import com.lite.machinelite.module.Module;
import com.lite.machinelite.utilities.TimerUtil;
import com.lite.machinelite.utilities.Utils;
import java.util.Random;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public class BuildRandom extends Module {
    private final Random random;
    private final TimerUtil timer;

    public BuildRandom(String name, int keyCode) {
        super(name, keyCode);
        random = new Random();
        timer = new TimerUtil();
    }

    @Override
    public void onEvent(Event event) {
        if (!isEnabled())
            return;

        if (event instanceof com.lite.machinelite.event.impl.RightClickMouseEvent) {
            int range = 4;
            int bound = range * 2 + 1;
            int attempts = 0;
            class_2338 pos;

            if (!checkHeldItem()) {
                return;
            }

            event.setCancelled(true);

            try {
                boolean placed = false;
                do {
                    pos = class_2338.method_49638(mc.field_1724.method_19538()).method_10069(random.nextInt(bound) - range,
                            random.nextInt(bound) - range, random.nextInt(bound) - range);
                    placed = tryToPlaceBlock(range, pos);
                } while (++attempts < 128 && timer.delay(80) && !placed);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private boolean tryToPlaceBlock(double reach, class_2338 pos) {
        if (pos == null || !mc.field_1687.method_8320(pos).method_45474()) {
            return false;
        }

        if (Utils.placeBlock(reach, pos)) {
            timer.reset();
            return true;
        }

        return false;
    }

    private boolean checkHeldItem() {
        if (mc.field_1724 == null)
            return false;
        class_1799 stack = mc.field_1724.method_6047();
        return !stack.method_7960() && stack.method_7909() instanceof class_1747;
    }
}
