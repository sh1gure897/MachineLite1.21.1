package com.lite.machinelite.module.impl;

import com.lite.machinelite.event.Event;
import com.lite.machinelite.event.impl.UpdateEvent;
import com.lite.machinelite.module.Module;
import com.lite.machinelite.utilities.TimerUtil;
import com.lite.machinelite.utilities.Utils;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public class FloorBuilder extends Module {
    private final TimerUtil timer;

    public FloorBuilder(String name, int keyCode) {
        super(name, keyCode);
        timer = new TimerUtil();
    }

    @Override
    public void onEvent(Event event) {
        if (!isEnabled())
            return;

        if (event instanceof UpdateEvent) {
            if (!checkHeldItem()) {
                return;
            }

            class_243 vec3d = mc.field_1724.method_19538();
            class_2338 originPos = class_2338.method_49637(vec3d.field_1352, vec3d.field_1351 - 1, vec3d.field_1350);
            int posX = originPos.method_10263();
            int posZ = originPos.method_10260();
            int range = 3;

            for (int x = posX - range; x <= posX + range; x++) {
                for (int z = posZ - range; z <= posZ + range; z++) {
                    if (timer.delay(80)) {
                        final class_2338 targetPos = new class_2338(x, originPos.method_10264(), z);
                        this.tryToPlaceBlock(range, targetPos);
                    }
                }
            }
        }
    }

    private void tryToPlaceBlock(double reach, class_2338 pos) {
        if (pos == null || !mc.field_1687.method_8320(pos).method_45474()) {
            return;
        }

        if (Utils.placeBlock(reach, pos)) {
            timer.reset();
        }
    }

    private boolean checkHeldItem() {
        if (mc.field_1724 == null)
            return false;
        return Utils.isBuilderBlock(mc.field_1724.method_6047());
    }
}
