package com.lite.machinelite.module.impl;

import com.lite.machinelite.event.Event;
import com.lite.machinelite.event.impl.RightClickMouseEvent;
import com.lite.machinelite.event.impl.UpdateEvent;
import com.lite.machinelite.module.Module;
import com.lite.machinelite.utilities.Utils;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_3965;

public class InstantWither extends Module {
    private int delay, lastSlot;

    public InstantWither(String name, int keyCode) {
        super(name, keyCode);
    }

    @Override
    public void onDisabled() {
        delay = 0;
        lastSlot = 0;
    }

    @Override
    public void onEvent(Event event) {
        if (!isEnabled())
            return;

        if (event instanceof RightClickMouseEvent) {
            if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332 || delay > 0) {
                return;
            }

            class_3965 blockHit = (class_3965) mc.field_1765;
            if (mc.field_1687.method_8320(blockHit.method_17777()).method_26215()
                    || mc.field_1724.method_6047().method_7909() != class_1802.field_8067) {
                return;
            }

            class_2338 startPos = blockHit.method_17777().method_10093(blockHit.method_17780());
            class_2350 front = mc.field_1724.method_5735();
            class_2350 left = front.method_10160();
            lastSlot = mc.field_1724.method_31548().field_7545;
            int[][] offset;
            byte b;
            int i;

            int sandSlot = Utils.getItemSlotByToolBar(class_1802.field_8067);
            int skullSlot = Utils.getItemSlotByToolBar(class_1802.field_8791);

            if (sandSlot != -1) {
                offset = new int[][] { new int[3], { 0, 1, 0 }, { 1, 1, 0 }, { -1, 1, 0 } };
                for (i = offset.length, b = 0; b < i;) {
                    int[] pos = offset[b];
                    this.placeBlocks(startPos.method_10086(pos[1]).method_10079(front, pos[2]).method_10079(left, pos[0]), sandSlot);
                    b++;
                }
            }

            if (skullSlot != -1) {
                offset = new int[][] { { 1, 2, 0 }, { 0, 2, 0 }, { -1, 2, 0 } };
                for (i = offset.length, b = 0; b < i;) {
                    int[] pos = offset[b];
                    this.placeBlocks(startPos.method_10086(pos[1]).method_10079(front, pos[2]).method_10079(left, pos[0]), skullSlot);
                    b++;
                }
            }

            event.setCancelled(true);
        }
        if (event instanceof UpdateEvent) {
            delay--;
        }
    }

    private void placeBlocks(class_2338 pos, int slot) {
        if (mc.field_1687.method_8320(pos).method_45474()) {
            Utils.switchItem(slot);
            Utils.placeBlock(4, pos);
            Utils.switchItem(lastSlot);
            delay = 2; // Keep original functionality exactly as is
        }
    }
}
