package com.lite.machinelite.module.impl;

import com.lite.machinelite.event.Event;
import com.lite.machinelite.event.impl.EventBreakBlock;
import com.lite.machinelite.module.Module;
import net.minecraft.class_2350;
import net.minecraft.class_2846;

public class AntiGhostBlock extends Module {
    public AntiGhostBlock(String name, int keyCode) {
        super(name, keyCode);
    }

    @Override
    public void onEvent(Event event) {
        if (!isEnabled())
            return;

        if (event instanceof EventBreakBlock) {
            EventBreakBlock breakEvent = (EventBreakBlock) event;
            mc.method_1562().method_52787(new class_2846(
                    class_2846.class_2847.field_12971, breakEvent.getPos(), class_2350.field_11036));
        }
    }
}
