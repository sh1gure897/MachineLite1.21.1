package com.lite.machinelite.module.impl;

import com.lite.machinelite.MachineLite;
import com.lite.machinelite.event.Event;
import com.lite.machinelite.event.impl.PacketEvent;
import com.lite.machinelite.event.impl.UpdateEvent;
import com.lite.machinelite.mixin.client.IMixinMapData;
import com.lite.machinelite.module.Module;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1799;
import net.minecraft.class_1806;
import net.minecraft.class_20;
import net.minecraft.class_22;
import net.minecraft.class_2683;
import net.minecraft.class_9209;
import net.minecraft.class_9334;

public class AntiMapBan extends Module {
    public AntiMapBan(String name, int keyCode) {
        super(name, keyCode);
    }

    @Override
    public void onEvent(Event event) {
        if (!isEnabled())
            return;

        if (event instanceof UpdateEvent) {
            class_1799 currentItem = mc.field_1724.method_6047();
            if (!currentItem.method_7960() && currentItem.method_7909() instanceof class_1806) {
                class_9209 mapId = currentItem.method_57824(class_9334.field_49646);
                if (mapId != null) {
                    class_22 mapState = mc.field_1687.method_17891(mapId);
                    if (mapState != null) {
                        this.getMapDecorations(mapState).clear();
                    }
                }
            }

            if (mc.field_1687 != null) {
                for (class_1297 entity : mc.field_1687.method_18112()) {
                    if (entity instanceof class_1533) {
                        class_1533 frame = (class_1533) entity;
                        class_1799 frameItem = frame.method_6940();
                        if (!frameItem.method_7960() && frameItem.method_7909() instanceof class_1806) {
                            class_9209 mapId = frameItem.method_57824(class_9334.field_49646);
                            if (mapId != null) {
                                class_22 mapState = mc.field_1687.method_17891(mapId);
                                if (mapState != null) {
                                    this.getMapDecorations(mapState).clear();
                                }
                            }
                        }
                    }
                }
            }
        }
        if (event instanceof PacketEvent) {
            if (((PacketEvent) event).getPacket() instanceof class_2683) {
                if (((PacketEvent) event).isIncoming()) {
                    event.setCancelled(true);
                }
            }
        }
    }

    public Map<String, class_20> getMapDecorations(class_22 mapState) {
        if (MachineLite.getModuleManager().isEnabled(Debug.class)) {
            MachineLite.WriteChat(String.format("MapInfo: [scale:%s, decorations:%s]", mapState.field_119,
                    this.getMapDecorations(mapState).size()));
        }

        return ((IMixinMapData) mapState).getMapDecorations();
    }
}
