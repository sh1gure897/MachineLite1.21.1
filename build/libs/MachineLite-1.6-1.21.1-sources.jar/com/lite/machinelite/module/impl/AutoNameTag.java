package com.lite.machinelite.module.impl;

import com.lite.machinelite.MachineLite;
import com.lite.machinelite.event.Event;
import com.lite.machinelite.event.impl.UpdateEvent;
import com.lite.machinelite.module.Module;
import com.lite.machinelite.utilities.Utils;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1528;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2828;

public class AutoNameTag extends Module {
    public List<class_1309> targets;
    private class_1309 target;

    public AutoNameTag(String name, int keyCode) {
        super(name, keyCode);
        this.targets = new ArrayList<>();
    }

    @Override
    public void onDisabled() {
        this.targets.clear();
        this.target = null;
    }

    @Override
    public void onEvent(Event event) {
        if (!isEnabled())
            return;

        if (event instanceof UpdateEvent) {
            this.collectTarget();

            if (target != null) {
                int tagSlot = (mc.field_1724.method_6047().method_7909() == class_1802.field_8448)
                        ? mc.field_1724.method_31548().field_7545
                        : Utils.getItemSlotByToolBar(class_1802.field_8448);
                int lastSlot = mc.field_1724.method_31548().field_7545;
                class_1799 currentItemStack = tagSlot != -1 ? mc.field_1724.method_31548().method_5438(tagSlot)
                        : class_1799.field_8037;

                if (tagSlot != -1 && this.check(target, currentItemStack.method_7964().getString())) {
                    Utils.switchItem(tagSlot);

                    class_238 boundingBox = target.method_5829();
                    class_243 vec3d = new class_243((boundingBox.field_1323 + boundingBox.field_1320) / 2.0D,
                            boundingBox.field_1322 + (boundingBox.field_1325 - boundingBox.field_1322) / 100.0D * 70,
                            (boundingBox.field_1321 + boundingBox.field_1324) / 2.0D);
                    float[] rotations = Utils.getNeededRotations(vec3d);
                    mc.method_1562().method_52787(new class_2828.class_2831(rotations[0],
                            rotations[1], mc.field_1724.method_24828()));
                    class_1269 result = mc.field_1761.method_2905(mc.field_1724, target, class_1268.field_5808);

                    if (result.method_23665()) {
                        MachineLite.WriteChat("Tagged " + target.method_5477().getString());
                    }

                    Utils.switchItem(lastSlot);
                }
            }
        }
    }

    public void collectTarget() {
        this.targets.clear();
        if (mc.field_1687 == null)
            return;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (mc.field_1724.method_5739(entity) < 6.0F) {
                if (entity instanceof class_1528) {
                    targets.add((class_1309) entity);
                }
            }
        }

        this.target = !targets.isEmpty() ? targets.get(0) : null;
    }

    private boolean check(class_1297 entity, String stackName) {
        if (!entity.method_16914())
            return true;
        String name = entity.method_5797().getString().toLowerCase().replaceAll(" ", "");
        return stackName.toLowerCase().replaceAll(" ", "").contains("ghosthax") ? !name.contains("ghosthax") : false;
    }
}
