package com.lite.machinelite.event.impl;

import com.lite.machinelite.event.Event;
import net.minecraft.class_332;

public class RenderOverlayEvent extends Event {
    private class_332 context;
    private float partialTicks;

    public RenderOverlayEvent fire(class_332 context, float partialTicks) {
        this.context = context;
        this.partialTicks = partialTicks;
        return this;
    }

    public class_332 getContext() {
        return context;
    }

    public float getPartialTicks() {
        return partialTicks;
    }
}

