package com.lite.machinelite.event.impl;

import com.lite.machinelite.event.Event;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_303;

public class ChatInputEvent extends Event {
    private class_2561 textComponent;
    private List<class_303.class_7590> chatLines;
    private boolean modified = false;

    public ChatInputEvent(class_2561 textComponent, List<class_303.class_7590> chatLines) {
        this.textComponent = textComponent;
        this.chatLines = chatLines;
    }

    public class_2561 getTextComponent() {
        return textComponent;
    }

    public void setTextComponent(class_2561 textComponent) {
        this.textComponent = textComponent;
        this.modified = true;
    }

    public boolean isModified() {
        return modified;
    }

    public List<class_303.class_7590> getChatLines() {
        return chatLines;
    }
}
