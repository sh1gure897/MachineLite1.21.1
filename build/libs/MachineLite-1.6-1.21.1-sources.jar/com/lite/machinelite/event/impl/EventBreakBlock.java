package com.lite.machinelite.event.impl;

import com.lite.machinelite.event.Event;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class EventBreakBlock extends Event {
    private class_2680 state;
    private class_2338 pos;

    public Event fire(class_2338 pos, class_2680 state) {
        this.pos = pos;
        this.state = state;
        return this;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2680 getState() {
        return state;
    }
}