package com.lite.machinelite.event.impl;

import com.lite.machinelite.event.Event;
import net.minecraft.class_2596;

public class PacketEvent extends Event {
    private class_2596<?> packet;
    private boolean outgoing;

    public Event preFire(class_2596<?> packet) {
        this.packet = packet;
        this.outgoing = true;
        return this;
    }

    public Event postFire(class_2596<?> packet) {
        this.packet = packet;
        this.outgoing = false;
        return this;
    }

    public class_2596<?> getPacket() {
        return this.packet;
    }

    public boolean isOutgoing() {
        return this.outgoing;
    }

    public boolean isIncoming() {
        return !this.outgoing;
    }
}

